
import csv
import folium
import json




def importCSV(fichier : str, separateur = ";"):
    tCSV = csv.DictReader(open(fichier,'r'), delimiter = separateur)
    tableau = []
    for ligne in tCSV:
        tableau.append(dict(ligne))
    return tableau


def Pays(Tableau) :
    b = []
    for dico in Tableau:
        b.append(dico["Country Name"])
    return b

def Valeurs(tableau,indice) :
    valeurs = []
    annee = 1990
    for i in range (annee,2019) : 
        provisoire = []
        for dico in tableau :
            a =(dico[str(annee)]) 
            b = convertisseur(a)
            provisoire.append(b)
        valeurs.append(provisoire[indice])
        annee = annee + 1
        provisoire = []
    return valeurs

def Retirervide (valeursPIB,valeursESP,annees) :
    valeursPIBprovisoires = []
    valeursESPprovisoires = []
    anneesprovisoires = []
    for i in range (0,29):
        if valeursPIB[i] != ('') and valeursESP[i] != (''):
            valeursPIBprovisoires.append(valeursPIB[i])
            valeursESPprovisoires.append(valeursESP[i])
            anneesprovisoires.append(annees[i])

    return[valeursPIBprovisoires,valeursESPprovisoires,anneesprovisoires]

def gps2(gps,pays):
    gps1 = []
    capitale = []
    latitude = []
    longitude = []
    i = 12
    for dico in gps :
        capitale.append(dico['CapitalName'])
        latitude.append(dico['CapitalLatitude'])
        longitude.append(dico['CapitalLongitude'])
    gps1.append(pays[i])
    gps1.append(capitale[i])
    gps1.append(latitude[i])
    gps1.append(longitude[i])
    i = i+1
    return gps1

def data(annees,TableauPib,TableauEsp,indice):
    valeursPib = Valeurs(TableauPib,indice)
    valeursEsp = Valeurs(TableauEsp,indice)
    valeursgenerale = Retirervide(valeursPib,valeursEsp,annees)
    data = []
    for i in range (len(valeursgenerale[0])):
        provisoire = {}
        provisoire ["année"] = valeursgenerale[2][i]
        provisoire ["PIB"] = valeursgenerale[0][i]
        provisoire ["ESP"] = valeursgenerale[1][i]
        data.append(provisoire)
    return data
    


def convertisseur (x):
    
    provisoire=''
    if x == '' : return provisoire
    for i in x:
        if i==',':
            provisoire+='.'
        else:
            provisoire+=i

    provisoire=float(provisoire)
    return provisoire

def templateJson(data, titre):
 jsonFile ={

  "title": titre ,
  "data": {
    "values":  data
  },
 
  "encoding": {
    "x": {
        "field": "année",
        "type": "temporal"

    }
  },
  "layer": [
    {
      "mark": {"opacity": 0.8, "type": "line", "color": "#fd0000"},
      "encoding": {
        "y": {
          "field": "PIB",
          "scale": {"domain": [0, 90000]},
          "type": "quantitative",
          "axis": {"title": "PIB moyen par hab (miliers de dollars)", "titleColor": "#fd0000"}
        },

        "y2": {
          "aggregate": "average",
          "field": "temp_min"
        }
      }
    },
    {
      "mark": {"stroke": "#0078d4", "type": "line", "interpolate": "monotone"},
      "encoding": {
        "y": {
          "aggregate": "average",
          "field": "ESP",
          "type": "quantitative",
          "axis": {"title": "Espérance de vie (années)", "titleColor":"#0078d4"}
        }
      }
    }
  ],
  "resolve": {"scale": {"y": "independent"}}
  }
 return jsonFile

    

def popup() :
    return

    
        
        
gps = importCSV('concap.csv')
TableauPib= importCSV('PIB4.csv')
TableauEsp = importCSV('ESP.csv')
pays =(Pays(TableauPib))
annees = ["1990","1991","1992","1993","1994","1995","1996","1997","1998","1999","2000","2001","2002","2003","2004","2005","2006","2007","2008","2009","2010","2011","2012","2013","2014","2015","2016","2017","2018"]





geo = json.load(open("world_country_boundaries.geojson.json"))

c= folium.Map(location=[-12.5, -77.050000],zoom_start=1)
b = 0
for i in gps :
    data1 = data(annees,TableauPib,TableauEsp,b)
    b = b+1
    folium.Marker([float(([i['CapitalLatitude']][0]).replace(",", ".")),float(([i['CapitalLongitude']][0]).replace(",", "."))],tooltip= [i['CapitalName']][0],popup=folium.Popup().add_child(folium.VegaLite(templateJson(data1,[i["CountryName"]][0])))).add_to(c)

folium.Choropleth(geo).add_to(c) 

c.save('maCarte.html') 












